/*
 * Copyright 2013-2019 Yash. https://Yash.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * For issues and patches go to: https://github.com/Yash
 */
package com.Yash.scoold.controllers;

import com.Yash.para.core.User;
import static com.Yash.para.core.User.Groups.MODS;
import static com.Yash.para.core.User.Groups.USERS;
import com.Yash.para.core.utils.ParaObjectUtils;
import com.Yash.para.utils.Config;
import com.Yash.para.utils.Pager;
import com.Yash.para.utils.Utils;
import static com.Yash.scoold.ScooldServer.PEOPLELINK;
import com.Yash.scoold.core.Post;
import com.Yash.scoold.core.Profile;
import com.Yash.scoold.core.Profile.Badge;
import com.Yash.scoold.utils.ScooldUtils;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import static com.Yash.scoold.ScooldServer.PROFILELINK;
import static com.Yash.scoold.ScooldServer.SIGNINLINK;
import com.Yash.scoold.core.Question;
import com.Yash.scoold.core.Reply;
import java.util.ArrayList;

/**
 *
 * @author Yash Asati
 */
@Controller
@RequestMapping("/profile")
public class ProfileController {

	private final ScooldUtils utils;

	@Inject
	public ProfileController(ScooldUtils utils) {
		this.utils = utils;
	}

	@GetMapping({"", "/{id}/**"})
	public String get(@PathVariable(required = false) String id, HttpServletRequest req, Model model) {
		if (!utils.isAuthenticated(req) && StringUtils.isBlank(id)) {
			return "redirect:" + SIGNINLINK + "?returnto=" + PROFILELINK;
		}
		Profile authUser = utils.getAuthUser(req);
		Profile showUser;
		boolean isMyProfile;

		if (StringUtils.isBlank(id) || isMyid(authUser, Profile.id(id))) {
			//requested userid !exists or = my userid => show my profile
			showUser = authUser;
			isMyProfile = true;
		} else {
			showUser = utils.getParaClient().read(Profile.id(id));
			isMyProfile = isMyid(authUser, Profile.id(id));
		}

		if (showUser == null || !ParaObjectUtils.typesMatch(showUser)) {
			return "redirect:" + PROFILELINK;
		}

		boolean protekted = !utils.isDefaultSpacePublic() && !utils.isAuthenticated(req);
		boolean sameSpace = (showUser.getSpaces().isEmpty() && utils.canAccessSpace(authUser, "")) ||
				(authUser != null && showUser.getSpaces().stream().anyMatch(s -> utils.canAccessSpace(authUser, s)));
		if (protekted || !sameSpace) {
			return "redirect:" + PEOPLELINK;
		}

		Pager itemcount1 = utils.getPager("page1", req);
		Pager itemcount2 = utils.getPager("page2", req);
		List<? extends Post> questionslist = getQuestions(authUser, showUser, isMyProfile, itemcount1);
		List<? extends Post> answerslist = getAnswers(authUser, showUser, isMyProfile, itemcount2);

		model.addAttribute("path", "profile.vm");
		model.addAttribute("title", utils.getLang(req).get("profile.title") + " - " + showUser.getName());
		model.addAttribute("description", getUserDescription(showUser, itemcount1.getCount(), itemcount2.getCount()));
		model.addAttribute("ogimage", showUser.getPicture());
		model.addAttribute("includeGMapsScripts", true);
		model.addAttribute("showUser", showUser);
		model.addAttribute("isMyProfile", isMyProfile);
		model.addAttribute("badgesCount", showUser.getBadgesMap().size());
		model.addAttribute("canEdit", isMyProfile || canEditProfile(authUser, id));
		model.addAttribute("canEditAvatar", Config.getConfigBoolean("avatar_edits_enabled", true));
		model.addAttribute("gravatarPicture", utils.getGravatar(showUser));
		model.addAttribute("itemcount1", itemcount1);
		model.addAttribute("itemcount2", itemcount2);
		model.addAttribute("questionslist", questionslist);
		model.addAttribute("answerslist", answerslist);
		model.addAttribute("nameEditsAllowed", Config.getConfigBoolean("name_edits_enabled", true));
		return "base";
	}

	@PostMapping(path = "/{id}", params = {"makemod"})
	public String mods(@PathVariable String id, @RequestParam Boolean makemod, HttpServletRequest req, HttpServletResponse res) {
		Profile authUser = utils.getAuthUser(req);
		if (!isMyid(authUser, Profile.id(id))) {
			Profile showUser = utils.getParaClient().read(Profile.id(id));
			if (showUser != null) {
				if (utils.isAdmin(authUser) && !utils.isAdmin(showUser)) {
					showUser.setGroups(makemod ? MODS.toString() : USERS.toString());
					showUser.update();
				}
			}
		}
		if (utils.isAjaxRequest(req)) {
			res.setStatus(200);
			return "base";
		} else {
			return "redirect:" + PROFILELINK + "/" + id;
		}
	}

	@PostMapping("/{id}")
	public String edit(@PathVariable(required = false) String id, @RequestParam(required = false) String name,
			@RequestParam(required = false) String location, @RequestParam(required = false) String website,
			@RequestParam(required = false) String aboutme, @RequestParam(required = false) String picture, HttpServletRequest req) {
		Profile authUser = utils.getAuthUser(req);
		if (canEditProfile(authUser, id)) {
			Profile showUser = authUser;
			boolean updateProfile = false;
			if (!isMyid(authUser, id)) {
				showUser = utils.getParaClient().read(Profile.id(id));
			}
			if (!StringUtils.equals(showUser.getLocation(), location)) {
				showUser.setLocation(location);
				updateProfile = true;
			}
			if (!StringUtils.equals(showUser.getWebsite(), website) &&
					(StringUtils.isBlank(website) || Utils.isValidURL(website))) {
				showUser.setWebsite(website);
				updateProfile = true;
			}
			if (!StringUtils.equals(showUser.getAboutme(), aboutme)) {
				showUser.setAboutme(aboutme);
				updateProfile = true;
			}
			if (Config.getConfigBoolean("avatar_edits_enabled", true) ||
					Config.getConfigBoolean("name_edits_enabled", true)) {
				updateProfile = updateUserPictureAndName(showUser, picture, name);
			}

			boolean isComplete = showUser.isComplete() && isMyid(authUser, showUser.getId());
			if (updateProfile || utils.addBadgeOnce(showUser, Badge.NICEPROFILE, isComplete)) {
				showUser.update();
			}
		}
		return "redirect:" + PROFILELINK + (isMyid(authUser, id) ? "" : "/" + id);
	}

	private boolean updateUserPictureAndName(Profile showUser, String picture, String name) {
		boolean updateProfile = false;
		boolean updateUser = false;
		User u = showUser.getUser();
		if (Config.getConfigBoolean("avatar_edits_enabled", true) &&
				!StringUtils.isBlank(picture) && (Utils.isValidURL(picture) || picture.startsWith("data:"))) {
			showUser.setPicture(picture);
			if (!u.getPicture().equals(picture) && !picture.contains("gravatar.com")) {
				u.setPicture(picture);
				updateUser = true;
			}
			updateProfile = true;
		}
		if (Config.getConfigBoolean("name_edits_enabled", true) && !StringUtils.isBlank(name)) {
			showUser.setName(name);
			if (StringUtils.isBlank(showUser.getOriginalName())) {
				showUser.setOriginalName(name);
			}
			if (!u.getName().equals(name)) {
				u.setName(name);
				updateUser = true;
			}
			updateProfile = true;
		}
		if (updateUser) {
			utils.getParaClient().update(u);
		}
		return updateProfile;
	}

	private boolean isMyid(Profile authUser, String id) {
		return authUser != null && (StringUtils.isBlank(id) || authUser.getId().equals(Profile.id(id)));
	}

	private boolean canEditProfile(Profile authUser, String id) {
		return isMyid(authUser, id) || utils.isAdmin(authUser);
	}

	private Object getUserDescription(Profile showUser, Long questions, Long answers) {
		if (showUser == null) {
			return "";
		}
		return showUser.getVotes() + " points, "
				+ showUser.getBadgesMap().size() + " badges, "
				+ questions + " questions, "
				+ answers + " answers "
				+ Utils.abbreviate(showUser.getAboutme(), 150);
	}

	private List<? extends Post> getQuestions(Profile authUser, Profile showUser, boolean isMyProfile, Pager itemcount) {
		if (utils.postsNeedApproval() && (isMyProfile || utils.isMod(authUser))) {
			List<Question> qlist = new ArrayList<>();
			Pager p = new Pager(itemcount.getPage(), itemcount.getLimit());
			qlist.addAll(showUser.getAllQuestions(itemcount));
			qlist.addAll(showUser.getAllUnapprovedQuestions(p));
			itemcount.setCount(itemcount.getCount() + p.getCount());
			return qlist;
		} else {
			return showUser.getAllQuestions(itemcount);
		}
	}

	private List<? extends Post> getAnswers(Profile authUser, Profile showUser, boolean isMyProfile, Pager itemcount) {
		if (utils.postsNeedApproval() && (isMyProfile || utils.isMod(authUser))) {
			List<Reply> alist = new ArrayList<>();
			Pager p = new Pager(itemcount.getPage(), itemcount.getLimit());
			alist.addAll(showUser.getAllAnswers(itemcount));
			alist.addAll(showUser.getAllUnapprovedAnswers(p));
			itemcount.setCount(itemcount.getCount() + p.getCount());
			return alist;
		} else {
			return showUser.getAllAnswers(itemcount);
		}
	}
}
