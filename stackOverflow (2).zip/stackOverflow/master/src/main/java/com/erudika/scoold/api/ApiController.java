package com.Yash.scoold.api;

import com.Yash.para.client.ParaClient;
import com.Yash.para.utils.Config;
import com.Yash.para.utils.Pager;
import com.Yash.para.utils.Utils;
import com.Yash.scoold.ScooldServer;
import com.Yash.scoold.core.Question;
import com.Yash.scoold.core.UnapprovedQuestion;
import com.Yash.scoold.utils.ScooldUtils;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * WORK IN PROGRESS.
 * @author Yash Asati
 */
@RestController
@RequestMapping("/api")
public class ApiController {

	private final ScooldUtils utils;
	private final ParaClient pc;

	@Inject
	public ApiController(ScooldUtils utils) {
		this.utils = utils;
		this.pc = utils.getParaClient();
	}

	@GetMapping
	public Map<String, Object> get(HttpServletRequest req, HttpServletResponse res) {
		Map<String, Object> intro = new HashMap<>();
		intro.put("message", Config.APP_NAME + " API, see docs at " + ScooldServer.getServerURL() + "/api.html");
		boolean healthy;
		try {
			healthy = pc != null && pc.getTimestamp() > 0;
		} catch (Exception e) {
			healthy = false;
		}
		intro.put("healthy", healthy);
		if (!healthy) {
			res.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
		return intro;
	}


	@GetMapping("/questions")
	public List<Question> getQuestions(@RequestParam(defaultValue = "*") String q, HttpServletRequest req) {
		Pager pager = utils.pagerFromParams(req);
		List<Question> questionslist = pc.findQuery(Utils.type(Question.class), q, pager);
		if (utils.postsNeedApproval()) {
			Pager p = new Pager(pager.getPage(), pager.getLimit());
			List<UnapprovedQuestion> uquestionslist = pc.findQuery(Utils.type(UnapprovedQuestion.class), q, p);
			List<Question> qlist = new LinkedList<>(uquestionslist);
			pager.setCount(pager.getCount() + p.getCount());
			qlist.addAll(questionslist);
			questionslist = qlist;
		}

		utils.fetchProfiles(questionslist);
		return questionslist;
	}

	@GetMapping("/question/{id}")
	public Question getQuestion(@PathVariable String id, HttpServletRequest req) {
		return pc.read(Utils.type(Question.class), id);
	}
}
